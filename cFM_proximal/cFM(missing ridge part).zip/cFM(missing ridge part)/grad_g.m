 function grad_g_Z=grad_g(Z,w,y,X)
 	[n,p]=size(X);
    grad_g_Z=-X'*(y-X*w-diag(X*Z*X'))*ones(1,n)*X; %%% not sure whether this is right or wrong...
 end